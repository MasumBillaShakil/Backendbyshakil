﻿namespace CapStoneProject.Models
{
    public class Registration
    {
        public int UserId { get; set; }
        public string fullName { get; set; }
        public string UserEmail { get; set; }
        public string Password { get; set; }
    }
}
